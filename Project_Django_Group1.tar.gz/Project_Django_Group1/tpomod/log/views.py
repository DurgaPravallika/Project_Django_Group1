#log/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.template.response import TemplateResponse
from django.shortcuts import render, redirect
# Create your views here.
# this login required decorator is to not allow to any  
# view without authenticating
from log.models import StudentInfo, Subjects, StudentSubject
from log.forms import SubjectForm, StudentInfoForm
from users.models import MyUser

@login_required(login_url="login/")
def home(request):
   #return render(request,"home.html")
   data = StudentInfo.objects.count()
   mrnd = StudentInfo.objects.filter(mrnd=1).count()
   wise = StudentInfo.objects.filter(wise=1).count()
   atl = StudentInfo.objects.filter(atl=1).count()
   iot = StudentInfo.objects.filter(iot=1).count()
   print data
   return TemplateResponse(request,"home.html",{"data": data,"wise":wise,"mrnd":mrnd,"atl":atl,"iot":iot})	

@login_required(login_url="login/")
def students(request):
   #return render(request,"home.html")
   studs = StudentInfo.objects.all()
   print studs
   return TemplateResponse(request,"students.html",{"studs": studs})	

@login_required(login_url="login/")
def filter(request):
    return render(request,"filter.html")


@login_required(login_url='/users/login/')
def subject_list(request):
   subjects = Subjects.objects.all()
   data = {"subjects": subjects}
   return TemplateResponse(request, "subject-list.html", data)


@login_required(login_url='/users/login/')
def add_subject(request):
   if request.method == "POST":
      form = SubjectForm(request.POST)
      if form.is_valid():
         form.save()
         return redirect("/subjects/")
   else:
      form = SubjectForm()
   data = {"form": form}
   return TemplateResponse(request, "add-subject.html", data)


@login_required(login_url='/users/login/')
def students_detail(request, id):
   try:
      user = MyUser.objects.get(id=id)
      if request.method == "POST":
         form = StudentInfoForm(request.POST)
         if form.is_valid():
            info_obj = form.save(commit=False)
            info_obj.student = user
            info_obj.save()
            return redirect("/students-detail/{}/".format(user.id))
      else:
         try:
            stundet_info = StudentInfo.objects.get(student=user)
            form = StudentInfoForm(instance=stundet_info)
         except:
            form = StudentInfoForm()

   except:
      user = None
      form = None
   data = {
      "user": user,
      "form": form
   }
   return TemplateResponse(request, "student-detail.html", data)
