from django.contrib import admin
from .models import StudentInfo

admin.site.register(StudentInfo)