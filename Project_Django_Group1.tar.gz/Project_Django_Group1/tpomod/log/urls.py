# log/urls.py
from django.conf.urls import url
from . import views

# We are adding a URL called /home
urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^students/$', views.students ,name='students'),
    url(r'^filter/$', views.filter ,name='filter'),
    url(r'^subjects/$', views.subject_list, name="subject_list"),
    url(r'^add-subject/$', views.add_subject, name="subject_add"),
    url(r'^students-detail/(?P<id>[0-9]+)/$', views.students_detail ,name='students_detail'),
]
