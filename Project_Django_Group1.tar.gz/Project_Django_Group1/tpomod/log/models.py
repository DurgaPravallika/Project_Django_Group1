
from django.db import models
from django.contrib.auth.models import User
from users.models import COURSES, SEMESTER, MyUser

class StudentInfo(models.Model):
   student = models.ForeignKey(MyUser, related_name="info_student", null=True)
   percentage = models.IntegerField(default=0)
   backlogs = models.IntegerField(default=0)
   wise = models.BooleanField(default=False)
   atl = models.BooleanField(default=False)
   mrnd = models.BooleanField(default=False)
   iot = models.BooleanField(default=False)


class Subjects(models.Model):
   name = models.CharField(max_length=300)
   course = models.CharField(max_length=100, choices=COURSES)
   semester = models.CharField(max_length=100, choices=SEMESTER)



class StudentSubject(models.Model):

   subject = models.ForeignKey(Subjects, null=True)

   date_started = models.DateField(null=True)

   date_end = models.DateField(null=True)

   attendance_count = models.IntegerField(default=0)

   percentage = models.FloatField(default=0.0)

   total_mark = models.IntegerField(default=0)

   status = models.CharField(max_length=20) #PASS, FAIL

   creaded_on = models.DateTimeField(auto_now_add=True)



