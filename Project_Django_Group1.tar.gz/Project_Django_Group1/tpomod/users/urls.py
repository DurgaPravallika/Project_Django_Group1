from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^login/$', views.user_login),
    url(r'^student-home/$', views.student_home),
    url(r'^staff-home/$', views.staff_home),
    url(r'^admin-home/$', views.admin_home),
    url(r'^add-student/$', views.add_student),
    url(r'^add-staff/$', views.add_staff),
    url(r'^logout/$', views.user_logout),
]