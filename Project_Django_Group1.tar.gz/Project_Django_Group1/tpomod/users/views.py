

# Create your views here.
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.template.response import TemplateResponse
from django.contrib.auth import logout
from django.contrib.auth.models import User

from users.forms import RegistrationForm, StudentInforForm
from users.models import MyUser, SEMESTER

# Create your views here.
def user_login(request):
    if request.method == "POST":
        email = request.POST["email"]
        password = request.POST["password"]

        user = authenticate(email=email, password=password)

        if user is not None:
            login(request, user)
            if user.user_type == "A":
                return  redirect("/user/admin-home/")
            elif user.user_type == "S":
                return redirect("/user/student-home/")
            elif user.user_type == "F":
                return redirect("/user/staff-home/")
            else:
                context = {"error": "Invalid Login!!!"}
        else:
            context = {"error": "Your username and password didn't match. Please try again"}

    else:
        context = {}

    template = loader.get_template('login.html')

    return HttpResponse(template.render(context, request))


@login_required(login_url='/users/login/')
def student_home(request):
    context = {
        "msg": "helllo"
    }
    template = loader.get_template('student-home.html')

    return HttpResponse(template.render(context, request))


@login_required(login_url='/users/login/')
def admin_home(request):
    staffs = MyUser.objects.filter(user_type="F")
    students = MyUser.objects.filter(user_type="S")
    context = {
        "staffs": staffs,
        "students": students
    }
    template = loader.get_template('admin-home.html')
    return HttpResponse(template.render(context, request))


@login_required(login_url='/users/login/')
def staff_home(request):

    semester = request.GET.get("semester", None)
    division = request.GET.get("division", None)

    students = MyUser.objects.filter(user_type="S")
    if semester:
        students = students.filter(info__semester=semester)
    if division:
        students = students.filter(info__division=division)

    context = {
        "students": students,
        "SEMESTER": SEMESTER
    }
    template = loader.get_template('staff-home.html')

    return HttpResponse(template.render(context, request))


@login_required(login_url='/users/login/')
def add_student(request):

    if request.method == "POST":
        form = RegistrationForm(request.POST)
        info_form = StudentInforForm(request.POST)
        if form.is_valid() and info_form.is_valid():
            user_obj = MyUser(user_type="S")
            user_obj.first_name = form.cleaned_data['first_name']
            user_obj.last_name= form.cleaned_data['last_name']
            user_obj.email= form.cleaned_data['email']
            user_obj.phone = form.cleaned_data['phone']
            user_obj.set_password(form.cleaned_data['password1'])
            user_obj.username = form.cleaned_data['email'].split("@")[0]
            user_obj.save()

            info_obj = info_form.save(commit=False)
            info_obj.user = user_obj
            info_obj.save()
            return redirect("/user/students/")
    else:
        form = RegistrationForm()
        info_form = StudentInforForm()
    data = {"form": form, "info_form": info_form}
    return TemplateResponse(request, "add-student.html", data)


@login_required(login_url='/users/login/')
def add_staff(request):

    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user_obj = MyUser(user_type="F")
            user_obj.first_name = form.cleaned_data['first_name']
            user_obj.last_name= form.cleaned_data['last_name']
            user_obj.email= form.cleaned_data['email']
            user_obj.phone = form.cleaned_data['phone']
            user_obj.set_password(form.cleaned_data['password1'])
            user_obj.username = form.cleaned_data['email'].split("@")[0]
            user_obj.save()

            return redirect("/user/staff/")
    else:
        form = RegistrationForm()
    data = {"form": form}
    return TemplateResponse(request, "add-staff.html", data)

def user_logout(request):
    logout(request)
    return redirect("/user/login/")