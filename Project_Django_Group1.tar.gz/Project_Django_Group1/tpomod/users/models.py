from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import ( AbstractUser, BaseUserManager )
# Create your models here.


class MyUserManager(BaseUserManager):
    def create_user(self, email, user_type, password=None):
        """
        Creates and saves a User with the given email, date of
        birth and password.
        """
        if not email:
            raise ValueError('Users must have an email address')

        user = self.model(
            email=self.normalize_email(email),
            username=email.split("@")[0],
            user_type=user_type
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, user_type, password):
        """
        Creates and saves a superuser with the given email, date of
        birth and password.
        """
        user = self.create_user(
            email,
            password=password,
            user_type=user_type
        )
        user.user_type = "A"
        user.is_superuser = True
        user.save(using=self._db)
        return user

class MyUser(AbstractUser):

    first_name = models.CharField(max_length=200,null=True, blank=True)

    last_name = models.CharField(max_length=200, null=True, blank=True)

    email = models.CharField(max_length=250, unique=True, db_index=True)

    user_type = models.CharField(max_length=1, default="S") # S = Student, F = Faculty

    phone = models.CharField(max_length=20, null=True, blank=True)

    dob = models.DateField(null=True, blank=True)

    gender = models.CharField(max_length=10) # Male/Female/Others

    objects = MyUserManager()


    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['phone',]

    def __str__(self):
        return self.email

    def get_display_name(self):
        if self.first_name and self.last_name:
            return self.first_name + " " +self.last_name
        elif self.first_name:
            return self.first_name
        else:
            return self.email.split("@")[0]

    def get_full_name(self):
        return self.first_name + " " + self.last_name


COURSES = (
        ('IT', 'Information Technology'),
        ('CSE', 'Computer Science'),
        ('EEE', 'Electrical And electronic Engineering'),
        ('ECE', 'Electronics And Communication Engineering')
    )
SEMESTER = (
        ('1', 'First Semester'),
('1', 'First Semester'),
('2', 'Second Semester'),
('3', 'Third Semester'),
('4', 'Fourth Semester'),
('5', 'Fifth Semester'),
('6', 'Sixth Semester'),
('7', 'Seventh Semester'),
('8', 'Eigth Semester')
    )

class StudentInfo(models.Model):


    user = models.OneToOneField(MyUser, related_name="info")

    academic_year = models.CharField(max_length=200, null=True, blank=True)

    course = models.CharField(max_length=100, null=True, choices=COURSES)

    semester = models.CharField(max_length=100, null=True, choices=SEMESTER)

    division = models.CharField(max_length=200, null=True, blank=True)


class AcademicDetails(models.Model):

    Aggregate = models.CharField(max_length=200, null=True, blank=True)

    backlogs = models.IntegerField()

    wise = models.IntegerField(default=0)

    atl = models.IntegerField(default=0)

    mrnd = models.IntegerField(default=0)

    iot = models.IntegerField(default=0)










