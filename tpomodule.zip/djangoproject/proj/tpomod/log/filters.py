from django import forms
from django.contrib.auth.models import User
from log.models import StudentInfo
import django_filters

class StudentFilter(django_filters.FilterSet):
     wise = django_filters.ModelMultipleChoiceFilter(queryset=StudentInfo.objects.all(), widget=forms.CheckboxSelectMultiple)

     class Meta:
        model = StudentInfo
        fields = ['percentage', 'backlogs','wise','atl','mrnd','iot']