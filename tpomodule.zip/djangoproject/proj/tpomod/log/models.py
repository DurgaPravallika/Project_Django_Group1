
from django.db import models
from django.contrib.auth.models import User
CATEGORY = (

('1','WISE'),
('2','MRND'),
('3','IOT'),
('4','ATL'),
)


#{{ form.first_aid }}



    
class StudentInfo(models.Model):
   username = models.CharField(max_length=100)
   percentage = models.IntegerField()
   name = models.CharField(max_length=150)
   backlogs = models.IntegerField()
   wise = models.IntegerField(default = 0)
   atl = models.IntegerField(default = 0)
   mrnd = models.IntegerField(default = 0)
   iot = models.IntegerField(default = 0)
   #filter=models.ManyToManyField(User, related_name="filter")
    
	