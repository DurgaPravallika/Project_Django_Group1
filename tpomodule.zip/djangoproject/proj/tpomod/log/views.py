#log/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.template.response import TemplateResponse
# Create your views here.
# this login required decorator is to not allow to any  
# view without authenticating
from log.models import StudentInfo
#from .filters import Filters


@login_required(login_url="login/")
def home(request):
   #return render(request,"home.html")
   data = StudentInfo.objects.count()
   mrnd = StudentInfo.objects.filter(mrnd=1).count()
   wise = StudentInfo.objects.filter(wise=1).count()
   atl = StudentInfo.objects.filter(atl=1).count()
   iot = StudentInfo.objects.filter(iot=1).count()
   print(data)
   return TemplateResponse(request,"home.html",{"data": data,"wise":wise,"mrnd":mrnd,"atl":atl,"iot":iot})	

@login_required(login_url="login/")
def students(request):
   #return render(request,"home.html")
   studs = StudentInfo.objects.all()
   print(studs)
   	
   wise = request.GET.get("wise", None)
   mrnd = request.GET.get("mrnd", None)
   #if wise:
    #   studs = studs.filter(info__wise=wise)
		
   return TemplateResponse(request,"students.html",{"studs": studs})
@login_required(login_url="login/")
def filter(request):

    category= request.GET.get("category", None)
    #division = request.GET.get("division", None)

    #students = MyUser.objects.filter(user_type="S")
    if category:
        students = students.filter(info__category=category)
   # if division:
    #    students = students.filter(info__division=division)

    context = {
        #"students": students,
        "category": category
    }
    #template = loader.get_template('filter.html')

    #return HttpResponse(template.render(context, request))
    return render(request,"filter.html")
	
#@login_required(login_url='/users/login/')
#def staff_home(request):
#def filter(request):
	#if request.method == 'POST':
		#form = FilterForm(request.POST)
		#if 'filter' in request.POST:
		#	wise = request.POST.getlist('wise')
		
			#mrnd = request.GET.get('mrnd')
		
			#atl = request.POST.getlist('atl')
			#iot = request.POST.getlist('iot')
			#percentage = request.POST.getlist('percentage')
	#return render(request,"students.html")
	#students = StudentInfo.objects.all()
	#students_filter = Filter(request.GET,queryset=students)
	#return render(request,'students.html',{'filter':students_filter})
    